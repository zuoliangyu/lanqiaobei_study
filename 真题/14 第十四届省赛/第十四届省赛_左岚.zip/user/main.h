#include "STC15F2K60S2.H"
#include "iic.h"
#include "onewire.h"
#include "ds1302.h"
#include "Key.h"
#include "Led.h"
#include "Seg.h"
#include "intrins.h"
#include "init.h"

#define uchar unsigned char
#define uint unsigned int