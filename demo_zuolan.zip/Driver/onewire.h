#ifndef __ONEWIRE_H
#define __ONEWIRE_H

float rd_temperature(void);
void start_Convert(void);
float read_temperture(void);
#endif
