#ifndef __ONEWIRE_H
#define __ONEWIRE_H

float rd_temperature(void);
#endif
