#include <STC15F2K60S2.H>
#include <stdio.h>
void UartInit(void); // 9600bps@12.000MHz