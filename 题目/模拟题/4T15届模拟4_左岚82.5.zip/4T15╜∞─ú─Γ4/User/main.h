#include "STC15F2K60S2.H"
#include "Led.h"
#include "Key.h"
#include "Seg.h"
#include "Init.h"
#include "iic.h"
#include "onewire.h"

#include "intrins.h"
#include "stdio.h"
#include "string.h"
#define uint unsigned int
#define uchar unsigned char