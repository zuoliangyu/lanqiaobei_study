#include "STC15F2K60S2.H"
unsigned char Ad_Read(unsigned char addr);
