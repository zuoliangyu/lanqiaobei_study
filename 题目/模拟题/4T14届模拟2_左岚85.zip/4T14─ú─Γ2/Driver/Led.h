#include "STC15F2K60S2.H"
void Led_Disp(unsigned char addr, unsigned char enable);
void Beep(bit enable);
void Relay(bit enable);