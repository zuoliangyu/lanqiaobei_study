#include "Init.h"
#include "Key.h"
#include "Led.h"
#include "STC15F2K60S2.H"
#include "Seg.h"
#include "ds1302.h"
#include "iic.h"
#include "intrins.h"
#include "onewire.h"
#include "stdio.h"
#define uint unsigned int
#define uchar unsigned char