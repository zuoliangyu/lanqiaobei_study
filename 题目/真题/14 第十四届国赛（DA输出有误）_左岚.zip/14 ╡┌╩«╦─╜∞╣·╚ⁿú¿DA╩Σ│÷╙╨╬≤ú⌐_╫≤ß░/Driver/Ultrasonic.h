#include "STC15F2K60S2.h"
unsigned int Ut_Wave_Data(char Cail, unsigned int speed);