void Set_Rtc(unsigned char *ucRtc);
void Read_Rtc(unsigned char *ucRtc);