#include <STC15F2K60S2.H>
#include "Seg.h"
#include "Led.h"
#include "Key.h"
#include "init.h"
#include "ds1302.h"
#include "iic.h"