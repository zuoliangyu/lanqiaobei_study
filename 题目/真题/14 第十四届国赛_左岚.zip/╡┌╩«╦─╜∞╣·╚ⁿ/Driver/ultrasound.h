#include <STC15F2K60S2.H>

unsigned char Ut_Wave_Data(char calibration_value, unsigned char transmission_speed);