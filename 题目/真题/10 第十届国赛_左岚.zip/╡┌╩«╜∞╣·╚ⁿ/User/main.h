#include "Init.h"
#include "Key.h"
#include "Led.h"
#include "STC15F2K60S2.H"
#include "Seg.h"
#include "Uart.h"
#include "Ultrasonic.h"
#include "iic.h"
#include "intrins.h"
#include "onewire.h"
#include "stdio.h"
#include "string.h"
#define uint unsigned int
#define uchar unsigned char