#include <STC15F2K60S2.H>
#include <stdio.h>
void Uart1_Init(void); // 9600bps@12.000MHz