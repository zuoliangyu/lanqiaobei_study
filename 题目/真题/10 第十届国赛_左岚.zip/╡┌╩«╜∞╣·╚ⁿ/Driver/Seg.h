#include <STC15F2K60S2.H>

void Seg_Disp(unsigned char wela,dula,point);