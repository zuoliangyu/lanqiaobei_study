#include <STC15F2K60S2.H>

#include "ds1302.h"
#include "iic.h"
#include "init.h"
#include "intrins.h"
#include "key.h"
#include "led.h"
#include "onewire.h"
#include "seg.h"
#include "stdio.h"
#include "string.h"
#include "uart.h"
#include "ul.h"
