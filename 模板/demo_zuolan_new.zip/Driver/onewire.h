#ifndef __ONEWIRE_H
#define __ONEWIRE_H



int rd_temperature(void);  

#endif
