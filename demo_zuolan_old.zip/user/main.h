#include "STC15F2K60S2.H"
#include "Led.h"
#include "Key.h"
#include "Seg.h"
#include "ds1302.h"
#include "iic.h"
#include "onewire.h"
#include "Uart.h"
#include "Ultrasonic.h"
#include "intrins.h"
#include "stdio.h"
#include "string.h"
#define uint unsigned int
#define uchar unsigned char